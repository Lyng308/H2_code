#include "Main.h"
void outhurra(bool rigtig, int maxGaet, int antalGaet, int compuTal) {
	if (rigtig == true) {
		printf("year");
	}
}