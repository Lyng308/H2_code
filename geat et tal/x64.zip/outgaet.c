#include "Main.h"
void outgaet(bool lavtHojt, int antalGaet) {
	if (lavtHojt == true) {
		system("cls");
		printf("tallet du g�tte p� var for H�jt		pr�v igen");
		printf("\nhvad for et tal g�tter du p�?: ");
	}
	if (lavtHojt == false) {
		system("cls");
		printf("tallet du g�tte p� var for Lavt		pr�v igen");
		printf("\nhvad for et tal g�tter du p�?: ");
	}
}