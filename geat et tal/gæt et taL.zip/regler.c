#include "Main.h"
void regler(void) {
	system("cls");
	printf("                    ______           _           \n");
	printf("                    | ___ \\         | |          \n");
	printf("                    | |_/ /___  __ _| | ___ _ __ \n");
	printf("                    |    // _ \\/ _` | |/ _ \\ '__|\n");
	printf("                    | |\\ \\  __/ (_| | |  __/ |   \n");
	printf("                    \\_| \\_\\___|\\__, |_|\\___|_|   \n");
	printf("                                __/ |            \n");
	printf("                               |___/             \n");

	printf("\n              =====================================");
	printf("\n              |                                   |");
	printf("\n              |                                   |");
	printf("\n              |                                   |");
	printf("\n              |                                   |");
	printf("\n              |                                   |");
	printf("\n              |                                   |");
	printf("\n              | tryk en tast for at komme tilbage |");
	printf("\n              =====================================");
}